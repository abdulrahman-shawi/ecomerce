# جلامور - المواصفات التقنية

## التبعيات

### إنتاجية

| Package | Version | Purpose |
|---------|---------|---------|
| react | ^19.0 | إطار عمل الواجهة الأمامية |
| react-dom | ^19.0 | عرض DOM لـ React |
| typescript | ^5.7 | التحقق من الأنواق |
| vite | ^6.2 | أداة البناء |
| tailwindcss | ^4.0 | إطار CSS |
| @tailwindcss/vite | ^4.0 | تكامل Tailwind مع Vite |

### مكونات واجهة المستخدم

| Package | Version | Purpose |
|---------|---------|---------|
| @radix-ui/react-dialog | ^1.1 | نافذة منبثقة لعربة التسوق |
| @radix-ui/react-tabs | ^1.1 | علامات التبويب لقسم المنتجات |
| @radix-ui/react-slot | ^1.1 | مكونات متعددة الاستخدامات |
| class-variance-authority | ^0.7 | إدارة اختلافات المكونات |
| clsx | ^2.1 | دمج أسماء الفئات الشرطية |
| tailwind-merge | ^3.0 | دمج فئات Tailwind |
| lucide-react | ^0.468 | أيقونات المتجهة |

### الرسوم المتحركة

| Package | Version | Purpose |
|---------|---------|---------|
| gsap | ^3.12 | محرك الرسوم المتحركة الرئيسي |
| @gsap/react | ^2.1 | تكامل GSap مع React |

### الخطوط

| Package | Version | Purpose |
|---------|---------|---------|
| @fontsource/tajawal | ^5.0 | الخط العربي الرئيسي |

## قائمة المكونات

### التخطيط

| Component | Source | Reuse | Notes |
|-----------|--------|-------|-------|
| TopBanner | Custom | Single | شريط إعلاني علوي قابل للإغلاق |
| Header | Custom | Single | هيدر مع تأثير blur عند التمرير |
| Footer | Custom | Single | فوتر بأربعة أعمدة |
| Layout | Custom | Single | تخطيط الصفحة الرئيسية |

### الأقسام

| Component | Source | Reuse | Notes |
|-----------|--------|-------|-------|
| HeroSlider | Custom | Single | سلايدر البطل الرئيسي |
| Features | Custom | Single | قسم المميزات |
| Categories | Custom | Single | قسم الفئات الشعبية |
| FeaturedProducts | Custom | Single | منتجات مميزة مع تبويبات |
| DualOffers | Custom | Single | بطاقتي عرض مزدوجة |
| BestSellers | Custom | Single | الأكثر مبيعاً |
| LimitedOffer | Custom | Single | عرض محدود مع عداد تنازلي |
| Testimonials | Custom | Single | آراء العملاء |
| Newsletter | Custom | Single | النشرة البريدية |

### مكونات مشتركة

| Component | Source | Reuse | Notes |
|-----------|--------|-------|-------|
| ProductCard | Custom | Multiple | بطاقة منتج مع زر أضف للسلة |
| CartDrawer | Custom | Single | نافذة عربة التسوق |
| CountdownTimer | Custom | Single | عداد تنازلي للعرض المحدود |
| StarRating | Custom | Multiple | تقييم بالنجوم |
| SectionTitle | Custom | Multiple | عنوان قسم موحد |

## خطة الرسوم المتحركة

| Animation | Library | Implementation Approach | Complexity |
|-----------|---------|------------------------|------------|
| تحميل الصفحة - شريط إعلاني | CSS | translateY من الأعلى + opacity | منخفض |
| تحميل الصفحة - هيدر | CSS | opacity تدريجي | منخفض |
| محتوى البطل - انزلاق | GSAP | translateX من اليسار + opacity | متوسط |
| صورة البطل - انزلاق | GSAP | translateX من اليمين + opacity | متوسط |
| تبديل السلايدر | GSAP | انزلاق أفقي بين الشرائح | متوسط |
| ظهور الأقسام عند التمرير | GSAP + ScrollTrigger | fade in up على كل قسم | متوسط |
| ظهور البطاقات المتتابع | GSAP + ScrollTrigger | stagger 100ms | متوسط |
| عداد تنازلي | CSS + JS | تحديث كل ثانية | منخفض |
| تأثير hover البطاقات | CSS | translateY(-8px) + box-shadow | منخفض |
| تأثير hover الأزرار | CSS | تغيير اللون + ظل | منخفض |
| تأثير hover الأيقونات | CSS | scale(1.1) + تغيير اللون | منخفض |

## State Management

Cart State: يتم إدارة حالة عربة التسوق باستخدام React Context API لتوفير:
- قائمة المنتجات في العربة
- إجمالي السعر
- عدد المنتجات
- إضافة/إزالة منتج

## الميزات المطلوبة

- [x] تخطيط فريد بدون قوالب جاهزة
- [x] عربة تسوق تفاعلية
- [x] سلايدر منتجات
- [x] عداد تنازلي
- [x] نافذة منبثقة للعربة
- [x] تأثيرات hover متنوعة
- [x] رسوم متحركة عند التمرير
- [x] تصميم متجاوب بالكامل
- [x] خط عربي مخصص
- [x] أيقونات متجهة
