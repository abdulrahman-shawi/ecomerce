import { CartProvider } from '@/context/CartContext';
import TopBanner from '@/sections/TopBanner';
import Header from '@/sections/Header';
import HeroSlider from '@/sections/HeroSlider';
import Features from '@/sections/Features';
import Categories from '@/sections/Categories';
import FeaturedProducts from '@/sections/FeaturedProducts';
import DualOffers from '@/sections/DualOffers';
import BestSellers from '@/sections/BestSellers';
import LimitedOffer from '@/sections/LimitedOffer';
import Testimonials from '@/sections/Testimonials';
import Newsletter from '@/sections/Newsletter';
import Footer from '@/sections/Footer';
import CartDrawer from '@/components/CartDrawer';

export default function Home() {
  return (
    <CartProvider>
      <div dir="rtl" className="font-tajawal min-h-screen bg-white">
        <TopBanner />
        <Header />
        <main>
          <HeroSlider />
          <Features />
          <Categories />
          <FeaturedProducts />
          <DualOffers />
          <BestSellers />
          <LimitedOffer />
          <Testimonials />
          <Newsletter />
        </main>
        <Footer />
        <CartDrawer />
      </div>
    </CartProvider>
  );
}
