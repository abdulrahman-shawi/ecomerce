import { useState } from 'react';
import SectionTitle from '@/components/SectionTitle';
import ProductCard from '@/components/ProductCard';
import type { Product } from '@/components/ProductCard';

const allProducts: Product[] = [
  { id: 1, name: 'سيروم فيتامين سي للوجه', price: 149, originalPrice: 199, image: '/images/products/serum.jpg', badge: 'الأكثر مبيعاً' },
  { id: 2, name: 'شامبو الكيراتين', price: 89, image: '/images/products/shampoo.jpg' },
  { id: 3, name: 'كريم مرطب لليل', price: 129, originalPrice: 169, image: '/images/products/night-cream.jpg' },
  { id: 4, name: 'ماسك الطين المغربي', price: 79, image: '/images/products/clay-mask.jpg', badge: 'جديد' },
  { id: 5, name: 'زيت الأرغان للشعر', price: 119, originalPrice: 149, image: '/images/products/argan-oil.jpg' },
  { id: 6, name: 'لوحة مكياج 40 لون', price: 199, image: '/images/products/makeup-palette.jpg' },
  { id: 7, name: 'بلسم الشفاه الوردي', price: 49, image: '/images/products/lip-balm.jpg', badge: 'عرض' },
  { id: 8, name: 'مجموعة العناية اليومية', price: 299, originalPrice: 399, image: '/images/products/gift-set.jpg', badge: 'وفّري 100 ريال' },
];

const tabs = [
  { key: 'all', label: 'الكل' },
  { key: 'bestseller', label: 'الأكثر مبيعاً' },
  { key: 'offer', label: 'العروض' },
  { key: 'new', label: 'جديد' },
];

export default function FeaturedProducts() {
  const [activeTab, setActiveTab] = useState('all');

  const filteredProducts = allProducts.filter((p) => {
    if (activeTab === 'all') return true;
    if (activeTab === 'bestseller') return p.badge === 'الأكثر مبيعاً';
    if (activeTab === 'offer') return p.originalPrice;
    if (activeTab === 'new') return p.badge === 'جديد';
    return true;
  });

  return (
    <section id="products" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <SectionTitle title="منتجاتنا المميزة" />

        {/* Tabs */}
        <div className="flex justify-center gap-2 mb-10 flex-wrap">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`px-6 py-2.5 rounded-full font-medium transition-all font-tajawal ${
                activeTab === tab.key
                  ? 'bg-pink text-white shadow-md'
                  : 'bg-gray-100 text-gray-600 hover:bg-pink-50 hover:text-pink'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </section>
  );
}
