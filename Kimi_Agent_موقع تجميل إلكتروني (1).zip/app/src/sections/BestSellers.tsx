import { useRef, useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import SectionTitle from '@/components/SectionTitle';
import ProductCard from '@/components/ProductCard';
import type { Product } from '@/components/ProductCard';

const products: Product[] = [
  { id: 1, name: 'سيروم فيتامين سي للوجه', price: 149, originalPrice: 199, image: '/images/products/serum.jpg', badge: 'الأكثر مبيعاً' },
  { id: 3, name: 'كريم مرطب لليل', price: 129, originalPrice: 169, image: '/images/products/night-cream.jpg' },
  { id: 5, name: 'زيت الأرغان للشعر', price: 119, originalPrice: 149, image: '/images/products/argan-oil.jpg' },
  { id: 8, name: 'مجموعة العناية اليومية', price: 299, originalPrice: 399, image: '/images/products/gift-set.jpg', badge: 'وفّري 100 ريال' },
  { id: 2, name: 'شامبو الكيراتين', price: 89, image: '/images/products/shampoo.jpg' },
  { id: 4, name: 'ماسك الطين المغربي', price: 79, image: '/images/products/clay-mask.jpg', badge: 'جديد' },
];

export default function BestSellers() {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  const checkScroll = () => {
    if (scrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
      setCanScrollLeft(scrollLeft > 0);
      setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 10);
    }
  };

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 320;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      });
      setTimeout(checkScroll, 300);
    }
  };

  return (
    <section className="py-20 bg-gray-light">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between mb-10">
          <SectionTitle title="الأكثر مبيعاً" />
          <div className="flex gap-2">
            <button
              onClick={() => scroll('right')}
              disabled={!canScrollRight}
              className="p-3 rounded-full border border-gray-200 hover:bg-pink hover:text-white hover:border-pink transition-all disabled:opacity-30 disabled:cursor-not-allowed"
            >
              <ChevronRight size={20} />
            </button>
            <button
              onClick={() => scroll('left')}
              disabled={!canScrollLeft}
              className="p-3 rounded-full border border-gray-200 hover:bg-pink hover:text-white hover:border-pink transition-all disabled:opacity-30 disabled:cursor-not-allowed"
            >
              <ChevronLeft size={20} />
            </button>
          </div>
        </div>

        <div
          ref={scrollRef}
          onScroll={checkScroll}
          className="flex gap-5 overflow-x-auto scrollbar-hide pb-4"
          style={{ scrollbarWidth: 'none' }}
        >
          {products.map((product) => (
            <div key={product.id} className="min-w-[260px] w-[260px] flex-shrink-0">
              <ProductCard product={product} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
