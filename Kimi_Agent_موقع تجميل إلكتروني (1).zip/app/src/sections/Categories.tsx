import SectionTitle from '@/components/SectionTitle';

const categories = [
  { name: 'العناية بالبشرة', image: '/images/categories/skincare.jpg' },
  { name: 'العناية بالشعر', image: '/images/categories/haircare.jpg' },
  { name: 'مكياج', image: '/images/categories/makeup.jpg' },
  { name: 'عطور', image: '/images/categories/perfume.jpg' },
  { name: 'أدوات تجميل', image: '/images/categories/tools.jpg' },
  { name: 'مجموعات هدايا', image: '/images/categories/gifts.jpg' },
];

export default function Categories() {
  return (
    <section id="categories" className="py-20 bg-gray-light">
      <div className="max-w-7xl mx-auto px-4">
        <SectionTitle title="تسوقي حسب الفئة" />
        <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
          {categories.map((cat, index) => (
            <div
              key={index}
              className="group cursor-pointer"
            >
              <div className="relative overflow-hidden rounded-2xl aspect-square mb-3">
                <img
                  src={cat.image}
                  alt={cat.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </div>
              <h3 className="text-center font-bold text-gray-dark font-tajawal group-hover:text-pink transition-colors">
                {cat.name}
              </h3>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
